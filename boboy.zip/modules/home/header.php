<div class="jumbotron bg-header img-responsive">
  <div class="container">
    <div class="col-md-12">
      <div class="container">
        <h2 class="text-center text-white header-text-big" style="text-transform: uppercase;">Need something?</h2>      
      </div>
    </div>
  </div>
</div>